<?php
       // arreglos formas de crear un arreglo

       //forma 1
       $meses[] = 'Enero';
       $meses[] = 'Febrero';
       $meses[] = 'Marzo';
       $meses[] = 'Abril';
       $meses[] = 'Mayo';
       $meses[] = 'Junio';
       $meses[] = 'Julio';
       $meses[] = 'Agiosto';
       $meses[] = 'Septiembre';
       $meses[] = 'Octubre';
       $meses[] = 'Noviembre';
       $meses[] = 'Diciembre';

        //forma 2
        $mes['enero'] = 31;
        $mes['febrero'] = 28;
        $mes[3] = 'Marzo';
        $mes[4] = 'Abril';
        $mes[5] = 'Mayo';
        $mes[6] = 'Junio';
        $mes[7] = 'Julio';
        $mes[8] = 'Agiosto';
        $mes[9] = 'Septiembre';
        $mes[10] = 'Octubre';
        $mes[11] = 'Noviembre';
        $mes[12] = 'Diciembre';
        

       echo $mes['febrero'].'<br>';

       //dinamica

        $diaSemana = array( 'lu' =>  'Lunes', 
                            'ma' => 'Martes',
                            'mi' =>   'Miercoles',
                            'ju' =>    'Jueves', 
                            'vi' =>    'Viernes',
                            'sa' =>  'Sabado', 
                            'do' =>   'Domingo');
        echo $diaSemana['lu'];

        //lectura de arreglos dinamicos
        $productos = array(  
                            array('precio'=>'10' ,'prod'=>'paquete de harina'), 
                            array('precio'=>'5' ,'prod'=>'Galletas'),
                            array('precio'=>'30' ,'prod'=>'Pan'),
                            array('precio'=>'7' ,'prod'=>'Helados'),
                            array('precio'=>'8' ,'prod'=>'Atun'),
                        );
   
       //ciclo for
       //for inicio , final, contador
        echo '<hr>';
        
        // acumuladores 

       for($i = 0; $i <= 10 ; $i+=2){
          //  echo ($i).'<br>';
       }

           //count();
           echo '<h1>Ciclo For</h1>';
         $obj = count($productos);
         $total = 0;
       for($i = 0; $i < $obj; $i++ ){

           $pr =  $productos[$i];
           echo $pr['prod'].' -------------------- $ '.$pr['precio']. ' usd';
           echo '<br>';  

           $total =  $total + $pr['precio'];
       }

        echo '<hr>';

        $imp = ($total * 12) / 100;
        echo 'Subtotal : '.$total.'<br>';
        echo 'Impuesto : '.$imp.'<br>';
        echo 'Total :    '.($total + $imp).'<br>'; 
          echo '<hr><hr>';
        // cilco while

        echo '<h1>Ciclo While</h1>';
        $obj = count($productos);
        $i = 0;
        $total = 0;
        while($i < $obj){

            $pr =  $productos[$i];
            echo $pr['prod'].' -------------------- $ '.$pr['precio']. ' usd';
            echo '<br>';  
            $total =  $total + $pr['precio'];
              
            $i++;
        }

        echo '<hr>';

        $imp = ($total * 12) / 100;

        echo 'Subtotal : '.$total.'<br>';
        echo 'Impuesto : '.$imp.'<br>';
        echo 'Total :    '.($total + $imp).'<br>'; 
          

        echo '<hr><hr><h1>Ciclo foreach</h1>';
          
        $total = 0;
        foreach($productos as $data){
            echo $data['prod'].' ---- '.$data['precio'] ;
            echo '<br>';
            $total =  $total + $data['precio'];
        }

        echo '<hr>';
        $imp = ($total * 12) / 100;

        echo 'Subtotal : '.$total.'<br>';
        echo 'Impuesto : '.$imp.'<br>';
        echo 'Total :    '.($total + $imp).'<br>'; 


?>