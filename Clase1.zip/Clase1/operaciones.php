<?php
  echo 'Suma de 2 números <br>';
  $valor1 = 5;
  echo 'Valor del numero 1: '.$valor1.'<br>';
  $valor2 = 1;
  echo 'Valor del numero 2: '.$valor2.'<br>';

  $suma = $valor1 + $valor2;
  echo 'El resultado de la suma es: '.$suma.'<br>';

  $multi = $valor1 * $valor2;
  echo 'El resultado de la multiplicación es: '.$multi.'<br>';
 
  $porc = ($multi * 30) / 100;


?>  