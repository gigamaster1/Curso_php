<?php
        $valor   =  @$_GET['valor'];
        $porc    =  @$_GET['porcentaje'];
        $calculo =  @($valor * $porc) / 100;
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de operaciones</title>
</head>

<body>

       <h1>Cálculo de porcentaje de un valor</h1>

       <form method="GET"  action="./calculo.php">
                Ingresa el valor<br>
               <input type="text" name="valor"><br>
               Ingrese el porcentaje<br>
               <input type="text" name="porcentaje">
               <br>
               <button>Calcular</button>
       </form>
            <br>
            El resultado es: <?php  echo $calculo; ?>
</body>

</html>