<?php  
   /* Asi se einicia una archivo php*/
     
   echo '<h1> Hola mundo</h1>   ';
   
   phpinfo();
      
   /* Asi culmina un archivo de php */
 ?>   
   
