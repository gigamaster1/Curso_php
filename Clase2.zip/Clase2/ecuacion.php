<?php
         // es tan sencicllo como dcir -b +- raiz de( b*b - 4*a*c) / 2 *a

    $a = 2;
    $b = 4;
    $c = -6;

   if(!is_integer($a) or !is_integer($b) or !is_integer($c)){
      echo 'los datos son invalidos';
      return;
   }
   
    $valor_raiz  = ($b * $b)  - 4 * $a * $c;
      if($valor_raiz < 1) 
      {
         echo 'la raiz no corta el eje de las X el valor es '.$valor_raiz;
         return;
      }

      
      // funcion 1 =  (-b - raiz) / 2 * $a 

      // funcion 2 =  (-b + raiz) / 2 * $a 

      $fun  =   (-$b - sqrt($valor_raiz)) / (2 * $a);
      $fun2 =   (-$b + sqrt($valor_raiz)) / (2 * $a);

      echo 'el valor de x1 = '.$fun.'<br>';
      echo 'el valor de x2= '.$fun2.'<br>';





?>       