<?php
   
      //validador or 
      
      $color1 = 'black';
      $color2 = 'red';

     if($color1 == 'red' or  $color2 == 'red') {
             echo 'existe el color rojo';
     }else{
             echo 'no existe el color rojo';
     }
     
     echo '<hr>';
     // validar el valor de una variable tru false;

     $var = 12.5;

     if(@is_integer($var) or is_float($var))     echo 'eL valor ingresado es un numero '.$var;
     else                                        echo 'el valor no es un numero';
    

    

?>