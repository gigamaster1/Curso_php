<?php
   
      //el mayor de tres 
      
      $a = 10;
      $b = 5;
      $c = 9;



     if($a > $b and $a > $c) {
            echo 'El mayor de los tress numeros es '.$a;
     }elseif($b > $c){

               echo 'el mayor es '.$b;
     }else{

                echo 'el mayor es '.$c;
     }

    

?>